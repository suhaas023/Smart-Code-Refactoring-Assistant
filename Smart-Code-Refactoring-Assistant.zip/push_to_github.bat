@echo off
title Push to GitHub - Smart Code Refactoring Assistant
echo ======================================================================
echo       Uploading Smart Refactoring Assistant to GitHub
echo       Repository: https://github.com/suhaas023/Smart-Code-Refactoring-Assistant
echo ======================================================================
echo.

:: Add portable git to path
set "PATH=C:\Users\kkris\.gemini\antigravity\bin\git\cmd;%PATH%"

echo Pushing code to branch 'main'...
echo (If prompted, sign in via browser or enter your personal access token)
echo.

git push -u origin main

if %ERRORLEVEL% equ 0 (
    echo.
    echo ======================================================================
    echo [SUCCESS] Your website is live on GitHub!
    echo Visit: https://github.com/suhaas023/Smart-Code-Refactoring-Assistant
    echo ======================================================================
) else (
    echo.
    echo [!] Push failed or cancelled.
    echo If prompted for password, use a GitHub Personal Access Token (PAT).
)

echo.
pause
