@echo off
title Smart Code Refactoring Assistant
echo ======================================================================
echo    Starting Smart Code Refactoring Assistant Server...
echo ======================================================================
cd /d "%~dp0"

echo Opening browser at http://localhost:8000 ...
start "" "http://localhost:8000"

python app.py
pause
