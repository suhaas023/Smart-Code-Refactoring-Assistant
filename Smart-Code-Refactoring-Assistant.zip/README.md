# 🚀 Smart Code Refactoring Assistant

A modern, responsive web application and developer productivity suite designed to help students, developers, and teams eliminate code smells, decrease cyclomatic complexity, enforce Clean Code standards, and modernize legacy codebases using **Google Gemini AI**.

---

## 🌟 Key Features

### 1. 📊 Executive Dashboard & Analytics
- **Live KPI Scorecards**: Total snippets refactored, code smells resolved, average complexity drop percentage, and saved developer hours.
- **Interactive Visualizations (Chart.js)**:
  - Code smell distribution breakdown (Maintainability, Security, Performance, Modern Syntax, OOP Architecture).
  - Cyclomatic complexity comparison (Before vs. After refactoring).
- **Recent Refactorings Feed**: Rapidly reload recently optimized snippets into the Studio.

### 2. ⚡ Smart Refactoring Studio & Dual Diff Workspace
- **Dual Workspace**: Side-by-side view with live line counters and syntax highlighting.
- **Unified Diff Engine**: Inspect line-by-line colored diffs (`+` additions, `-` removals, `@@` chunks) with a single click.
- **6 Multi-Paradigm Refactoring Goals**:
  1. 🧼 **Clean Code & Readability**: SOLID principles, small single-responsibility functions, guard clauses, self-documenting naming.
  2. ⚡ **Performance & Optimization**: Vectorization, memoization, eliminating $O(N^2)/O(N^3)$ nested loops, memory optimization.
  3. 🛡️ **Security Hardening**: Remediation of OWASP Top 10 vulnerabilities (SQL Injection, hardcoded secrets, unhandled exceptions).
  4. 🚀 **Modern Syntax & Idioms**: Upgrades to modern language features (Python 3.11+ type hints/match-case, ES6+ async/await/destructuring).
  5. 🏗️ **Design Patterns & Architecture**: Strategy, Factory, and Dependency Injection decoupled architectures.
  6. 🧪 **Testability & Type Safety**: Pure functions, deterministic behavior, and static type annotations.
- **Preloaded Student Presets**:
  - *E-Commerce Checkout & Tax Pipeline* (Monolithic spaghetti function)
  - *User Authentication & Database Query* (SQL Injection vulnerability & plaintext passwords)
  - *Matrix Multiplication & Grid Search* (Cubic $O(N^3)$ nested loop)
  - *Student Grade Analyzer & Report Card* (Legacy Python 2 patterns & bare exceptions)
  - *Weather Data Fetcher & Formatter* (Callback hell & UI tight coupling)

### 3. 🔍 Code Smell & Static Analysis Engine
- **Real Python AST Analysis**:
  - Cyclomatic Complexity calculation
  - Cognitive Complexity calculation
  - Detection of God Functions / Long Methods (>30 lines)
  - Parameter list bloat (>5 parameters)
  - Mutable default arguments (`def func(items=[])`)
  - Bare exception handlers (`except:`)
  - Deep nesting depth ($\ge 4$ levels)
  - Magic number detection
- **Multi-Language Heuristics**: Support for JavaScript, TypeScript, Java, C++, Go.

### 4. 📁 Snippets Library (Interactive Data Table & Cards)
- Search across titles, code content, and smell descriptions.
- Filter by programming language and refactoring approval status.
- Toggle between dynamic **Cards Grid** and **Data Table** views.
- Edit, inspect audit reports, or delete snippets.

### 5. 📄 Export & Audit Reporting Tools
- **Code Export**: One-click download of cleaned source files (`.py`, `.js`, `.ts`, `.java`, `.cpp`, `.go`).
- **Markdown Audit Reports**: Comprehensive `.md` report generation containing executive summaries, quantitative delta tables, smell resolution logs, and clean code diffs.
- **Print / PDF Ready**: Clean modal layout ready for printing or exporting to PDF.

### 6. 🤖 Google Gemini AI Integration
- Powered by `gemini-2.5-flash` or `gemini-1.5-flash`.
- Uses strict structured JSON responses for deterministic refactor outputs.
- **Built-in Offline / Demo Mode**: Intelligent AST-based fallback generator ensures full functionality without requiring an active internet connection or API key.

---

## 🛠️ Getting Started

### Prerequisites
- Python 3.10+ (Standard library includes SQLite3 and HTTP server; `requests` is optional and supported)

### Quick Launch (Windows)
1. Double click [`run.bat`](file:///C:/Users/kkris/.gemini/antigravity/scratch/smart-refactor-assistant/run.bat) or run in PowerShell:
   ```powershell
   .\run.ps1
   ```
2. Your browser will automatically open:
   ```
   http://localhost:8000
   ```

### Manual Command Line Launch
```bash
python app.py
```

---

## ⚙️ Configuring Google Gemini API Key

1. Generate a free API key at [Google AI Studio](https://aistudio.google.com/app/apikey).
2. Open the application, navigate to the **Settings** tab, paste your key, and click **Save Settings**.
3. Alternatively, export it as an environment variable before starting:
   ```powershell
   $env:GEMINI_API_KEY="your_api_key_here"
   python app.py
   ```

---

## 📂 Project Architecture

```
smart-refactor-assistant/
├── app.py              # Threaded Python HTTP server, SQLite DB, AST & Gemini API engine
├── static/
│   └── index.html      # Responsive Single Page App (Tailwind CSS, Lucide, Chart.js, Prism.js)
├── database.db         # SQLite database storing refactored snippets & benchmark records
├── config.json         # Local settings for Gemini API & model preferences
├── run.bat             # 1-click Windows launcher
├── run.ps1             # PowerShell launcher
├── requirements.txt    # Optional Python dependencies
└── README.md           # Documentation
```
