# Contributing to Smart Code Refactoring Assistant

Thank you for your interest in contributing! Here's how you can get started:

## Development Setup

1. Fork the repository on GitHub.
2. Clone your fork locally:
   ```bash
   git clone https://github.com/<your-username>/smart-code-refactoring-assistant.git
   cd smart-code-refactoring-assistant
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the development server:
   ```bash
   python app.py
   ```
5. Open `http://localhost:8000` in your browser.

## Submitting Pull Requests

1. Create a feature branch (`git checkout -b feature/amazing-feature`).
2. Commit your changes with descriptive messages (`git commit -m "feat: add AST support for Go loops"`).
3. Push to your branch (`git push origin feature/amazing-feature`).
4. Open a Pull Request on GitHub.
