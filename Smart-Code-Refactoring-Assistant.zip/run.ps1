# Smart Code Refactoring Assistant - PowerShell Launcher
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "   Starting Smart Code Refactoring Assistant Server..." -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

Start-Process "http://localhost:8000"
python app.py
