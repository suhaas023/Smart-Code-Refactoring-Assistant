# Push to GitHub PowerShell Helper
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "       Uploading Smart Refactoring Assistant to GitHub" -ForegroundColor Cyan
Write-Host "       Repository: https://github.com/suhaas023/Smart-Code-Refactoring-Assistant" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan

$env:Path = "C:\Users\kkris\.gemini\antigravity\bin\git\cmd;$env:Path"

Write-Host "Pushing code to branch 'main'..." -ForegroundColor Green
Write-Host "(If prompted, sign in via browser or enter your personal access token)`n" -ForegroundColor Yellow

git push -u origin main

if ($LASTEXITCODE -eq 0) {
    Write-Host "`n[SUCCESS] Your website is live on GitHub!" -ForegroundColor Green
    Write-Host "Visit: https://github.com/suhaas023/Smart-Code-Refactoring-Assistant" -ForegroundColor Cyan
} else {
    Write-Host "`n[!] Push failed or cancelled." -ForegroundColor Red
}
Write-Host "`nPress any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
