#!/usr/bin/env python3
"""
Direct GitHub REST API Uploader
Uploads the Smart Refactor Assistant project directly to GitHub without requiring Git CLI.
"""

import os
import sys
import base64
import json
import urllib.request
import urllib.error

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

IGNORE_FILES = {
    "database.db", "database.db-journal", "config.json",
    ".DS_Store", "Thumbs.db", ".git"
}
IGNORE_DIRS = {
    "__pycache__", ".venv", "venv", ".git"
}

def github_request(endpoint, token, method="GET", data=None):
    url = f"https://api.github.com{endpoint}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "RefactorAI-Uploader"
    }
    body = json.dumps(data).encode("utf-8") if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8")
        try:
            return e.code, json.loads(error_body)
        except Exception:
            return e.code, {"message": error_body}

def get_current_user(token):
    status, data = github_request("/user", token)
    if status == 200:
        return data.get("login")
    return None

def create_or_get_repo(token, repo_name, is_private=False):
    status, data = github_request("/user/repos", token, method="POST", data={
        "name": repo_name,
        "description": "Smart Code Refactoring Assistant with Google Gemini AI",
        "private": is_private,
        "auto_init": False
    })
    if status in (200, 201):
        print(f"[+] Repository '{repo_name}' created successfully.")
        return data.get("html_url")
    elif status == 422:
        # Repository likely already exists
        user = get_current_user(token)
        print(f"[*] Repository '{repo_name}' already exists. Uploading files to existing repository...")
        return f"https://github.com/{user}/{repo_name}"
    else:
        print(f"[-] Failed to create repository: {data.get('message')}")
        return None

def upload_file(token, username, repo_name, local_path, repo_path):
    with open(local_path, "rb") as f:
        content_b64 = base64.b64encode(f.read()).decode("utf-8")

    # Check if file exists to get SHA for update
    endpoint = f"/repos/{username}/{repo_name}/contents/{repo_path}"
    status, existing = github_request(endpoint, token)
    
    payload = {
        "message": f"Add {repo_path}",
        "content": content_b64
    }
    if status == 200 and "sha" in existing:
        payload["sha"] = existing["sha"]
        payload["message"] = f"Update {repo_path}"

    put_status, resp = github_request(endpoint, token, method="PUT", data=payload)
    if put_status in (200, 201):
        print(f"  ✓ Uploaded: {repo_path}")
        return True
    else:
        print(f"  ✗ Failed {repo_path}: {resp.get('message')}")
        return False

def upload_all(token, repo_name):
    username = get_current_user(token)
    if not username:
        print("[-] Invalid GitHub Token. Please check your token and try again.")
        return False

    print(f"[+] Authenticated as GitHub user: @{username}")
    repo_url = create_or_get_repo(token, repo_name)
    if not repo_url:
        return False

    print(f"\n[*] Uploading project files to {repo_url}...")
    count = 0
    for root, dirs, files in os.walk(PROJECT_DIR):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for file in files:
            if file in IGNORE_FILES or file == "upload_to_github.py":
                continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, PROJECT_DIR).replace("\\", "/")
            if upload_file(token, username, repo_name, full_path, rel_path):
                count += 1

    print(f"\n🎉 Successfully uploaded {count} files to GitHub!")
    print(f"🔗 View your repository at: {repo_url}")
    return True

if __name__ == "__main__":
    if len(sys.argv) >= 3:
        token = sys.argv[1].strip()
        repo = sys.argv[2].strip()
    else:
        token = input("Enter your GitHub Personal Access Token (classic with 'repo' scope): ").strip()
        repo = input("Enter repository name [smart-code-refactoring-assistant]: ").strip() or "smart-code-refactoring-assistant"

    if not token:
        print("[-] Error: Token cannot be empty.")
        sys.exit(1)

    upload_all(token, repo)
